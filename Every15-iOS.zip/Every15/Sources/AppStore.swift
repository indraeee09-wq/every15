import Foundation
import SwiftUI

@MainActor
final class AppStore: ObservableObject {
    static let shared = AppStore()

    @Published var config: Config { didSet { saveConfig() } }
    @Published var secret: String { didSet { Keychain.set(secret, for: Self.secretKey) } }
    @Published private(set) var run: RunState?
    @Published private(set) var busy: String? = nil
    @Published var error: String? = nil
    @Published var info: String? = nil

    private var inFlight = false
    private static let configKey = "every15.config.v1"
    private static let secretKey = "twilio-secret"

    private init() {
        if let d = UserDefaults.standard.data(forKey: Self.configKey),
           let c = try? JSONDecoder().decode(Config.self, from: d) {
            config = c
        } else {
            config = Config()
        }
        secret = Keychain.get(Self.secretKey)
        run = Self.loadRun()
    }

    // MARK: - Derived state

    var isRunning: Bool { run != nil }
    var pending: [ScheduledMessage] {
        let now = Date()
        return run?.items.filter { $0.status == "scheduled" && $0.sendAt > now } ?? []
    }
    var nextSend: Date? { pending.first?.sendAt }

    // MARK: - Actions

    func sendTest() async {
        guard !inFlight else { return }
        let c = config.normalized
        if let e = validationError(c) { error = e; return }
        inFlight = true
        busy = "Sending test…"
        defer { inFlight = false; busy = nil }
        do {
            let m = try await client(c).send(to: c.address, serviceSid: c.serviceSid,
                                             body: Slots.render(c.message, n: 0, at: Date()))
            error = nil
            info = "Test sent (\(m.status))."
        } catch let e {
            error = e.localizedDescription
        }
    }

    func start() async {
        guard run == nil, !inFlight else { return }
        let c = config.normalized
        if let e = validationError(c) { error = e; return }
        error = nil
        info = nil
        let now = Date()
        var state = RunState(
            config: c, startedAt: now,
            endAt: c.runLength == .forever ? nil : now.addingTimeInterval(TimeInterval(c.runLength.rawValue) * 3600),
            nextN: 1, lastSlot: nil, items: [])

        if c.sendFirstNow {
            inFlight = true
            busy = "Sending first message…"
            do {
                let m = try await client(c).send(to: c.address, serviceSid: c.serviceSid,
                                                 body: Slots.render(c.message, n: 1, at: now))
                state.items.append(ScheduledMessage(sid: m.sid, n: 1, sendAt: now, status: m.status))
                state.nextN = 2
            } catch let e {
                error = e.localizedDescription
                inFlight = false
                busy = nil
                return
            }
            inFlight = false
        }
        persist(state)
        await topUp(limit: 400)
    }

    /// Hands Twilio the next batch of timed messages, up to `limit` per call.
    func topUp(limit: Int) async {
        guard var state = run, !inFlight else { return }
        inFlight = true
        defer { inFlight = false; busy = nil }

        let c = state.config
        let now = Date()
        let earliest = now.addingTimeInterval(Slots.minLead)
        let hardCap = now.addingTimeInterval(Slots.maxLead)
        let target = min(state.endAt ?? now.addingTimeInterval(Slots.foreverHorizon), hardCap)

        var plan: [(n: Int, at: Date)] = []
        var prev = state.lastSlot
        var n = state.nextN
        while plan.count < limit {
            let t = Slots.next(after: prev, earliest: earliest, intervalMin: c.intervalMin, align: c.align)
            guard t <= target else { break }
            plan.append((n, t))
            prev = t
            n += 1
        }

        if plan.isEmpty {
            // Fixed-length run fully queued and everything has gone out → done.
            if let end = state.endAt, end <= hardCap, !state.items.contains(where: { $0.sendAt > now }) {
                persist(nil)
                info = "Run finished."
            }
            return
        }

        let cl = client(c)
        var done = 0
        var failure: Error?
        for i in stride(from: 0, to: plan.count, by: 4) {
            let chunk = plan[i..<min(i + 4, plan.count)]
            busy = "Scheduling \(done + 1)–\(done + chunk.count) of \(plan.count)…"
            let results = await withTaskGroup(of: Result<ScheduledMessage, Error>.self,
                                              returning: [Result<ScheduledMessage, Error>].self) { group in
                for item in chunk {
                    let body = Slots.render(c.message, n: item.n, at: item.at)
                    let to = c.address, service = c.serviceSid
                    let slotN = item.n, slotAt = item.at
                    group.addTask {
                        do {
                            let m = try await cl.schedule(to: to, serviceSid: service, body: body, at: slotAt)
                            return .success(ScheduledMessage(sid: m.sid, n: slotN, sendAt: slotAt, status: m.status))
                        } catch {
                            return .failure(error)
                        }
                    }
                }
                var out: [Result<ScheduledMessage, Error>] = []
                for await r in group { out.append(r) }
                return out
            }
            for r in results {
                switch r {
                case .success(let m):
                    state.items.append(m)
                    if state.lastSlot.map({ m.sendAt > $0 }) ?? true { state.lastSlot = m.sendAt }
                    state.nextN = max(state.nextN, m.n + 1)
                case .failure(let e):
                    if failure == nil { failure = e }
                }
            }
            state.items.sort { $0.sendAt < $1.sendAt }
            persist(state)   // save after every chunk so no SID is ever lost
            done += chunk.count
            if failure != nil { break }
        }
        if let f = failure {
            error = "Scheduling stopped: \(f.localizedDescription)"
        } else {
            error = nil
        }
    }

    /// Cancels every message still queued at Twilio and ends the run.
    func stop() async {
        guard let state = run, !inFlight else { return }
        inFlight = true
        defer { inFlight = false; busy = nil }

        let cl = client(state.config)
        let cutoff = Date().addingTimeInterval(30)
        let targets = state.items.filter { $0.status == "scheduled" && $0.sendAt > cutoff }.map(\.sid)
        var failed: [String] = []
        var done = 0
        for i in stride(from: 0, to: targets.count, by: 6) {
            let chunk = targets[i..<min(i + 6, targets.count)]
            busy = "Canceling \(done + 1)–\(done + chunk.count) of \(targets.count)…"
            let bad = await withTaskGroup(of: String?.self, returning: [String].self) { group in
                for sid in chunk {
                    group.addTask { (try? await cl.cancel(sid: sid)) == nil ? sid : nil }
                }
                var out: [String] = []
                for await s in group { if let s { out.append(s) } }
                return out
            }
            failed += bad
            done += chunk.count
        }

        if failed.isEmpty {
            persist(nil)
            error = nil
            info = "Stopped. Canceled \(targets.count) queued message(s)."
        } else {
            // Keep the ones that didn't cancel so Stop can be retried; schedule nothing new.
            var s = state
            let keep = Set(failed)
            s.items = s.items.filter { keep.contains($0.sid) }
            s.endAt = Date()
            persist(s)
            error = "\(failed.count) of \(targets.count) couldn't be canceled. Tap Stop again, or cancel them in the Twilio console."
        }
    }

    // MARK: - Helpers

    func validationError(_ c: Config) -> String? {
        if !c.accountSid.hasPrefix("AC") || c.accountSid.count != 34 { return "Account SID should start with AC (34 characters)." }
        if !c.apiKeySid.isEmpty && !c.apiKeySid.hasPrefix("SK") { return "API Key SID should start with SK." }
        if secret.isEmpty { return c.apiKeySid.isEmpty ? "Enter your Auth Token." : "Enter your API Key secret." }
        if !c.serviceSid.hasPrefix("MG") { return "A Messaging Service SID (MG…) is needed for scheduling." }
        if c.to.range(of: #"^\+\d{8,15}$"#, options: .regularExpression) == nil {
            return "Number must include the country code, e.g. +919876543210."
        }
        if c.message.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return "Message is empty." }
        if c.message.count > 1600 { return "Message is over 1600 characters." }
        return nil
    }

    private func client(_ c: Config) -> TwilioClient {
        TwilioClient(accountSid: c.accountSid,
                     username: c.apiKeySid.isEmpty ? c.accountSid : c.apiKeySid,
                     secret: secret.trimmingCharacters(in: .whitespacesAndNewlines))
    }

    private func saveConfig() {
        if let d = try? JSONEncoder().encode(config) { UserDefaults.standard.set(d, forKey: Self.configKey) }
    }

    private static var runURL: URL {
        let dir = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir.appendingPathComponent("run.json")
    }

    private static func loadRun() -> RunState? {
        guard let d = try? Data(contentsOf: runURL) else { return nil }
        return try? JSONDecoder().decode(RunState.self, from: d)
    }

    private func persist(_ state: RunState?) {
        guard var s = state else {
            run = nil
            try? FileManager.default.removeItem(at: Self.runURL)
            return
        }
        // Keep only the 50 most recent already-sent entries.
        let now = Date()
        let past = s.items.filter { $0.sendAt <= now }
        if past.count > 50 {
            let drop = Set(past.prefix(past.count - 50).map(\.sid))
            s.items.removeAll { drop.contains($0.sid) }
        }
        run = s
        if let d = try? JSONEncoder().encode(s) {
            try? d.write(to: Self.runURL, options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
        }
    }
}
