import Foundation

enum Channel: String, Codable, CaseIterable, Identifiable {
    case sms, whatsapp
    var id: String { rawValue }
    var label: String { self == .sms ? "SMS" : "WhatsApp" }
}

enum RunLength: Int, Codable, CaseIterable, Identifiable {
    case oneHour = 1, sixHours = 6, oneDay = 24, oneWeek = 168, thirtyFiveDays = 840, forever = 0
    var id: Int { rawValue }
    var label: String {
        switch self {
        case .oneHour: return "1 hour"
        case .sixHours: return "6 hours"
        case .oneDay: return "24 hours"
        case .oneWeek: return "7 days"
        case .thirtyFiveDays: return "35 days"
        case .forever: return "Until I stop it"
        }
    }
}

struct Config: Codable, Equatable {
    var to = ""
    var message = "Ping {n} at {time}"
    var channel: Channel = .sms
    var intervalMin = 15
    var align = true
    var sendFirstNow = true
    var runLength: RunLength = .oneDay
    var accountSid = ""
    var apiKeySid = ""
    var serviceSid = ""

    var normalized: Config {
        var c = self
        c.to = to.filter { !$0.isWhitespace && $0 != "-" && $0 != "(" && $0 != ")" }
        c.accountSid = accountSid.trimmingCharacters(in: .whitespacesAndNewlines)
        c.apiKeySid = apiKeySid.trimmingCharacters(in: .whitespacesAndNewlines)
        c.serviceSid = serviceSid.trimmingCharacters(in: .whitespacesAndNewlines)
        return c
    }

    /// Twilio "To" value for the selected channel.
    var address: String { channel == .whatsapp ? "whatsapp:\(to)" : to }
}

struct ScheduledMessage: Codable, Identifiable, Equatable, Sendable {
    var id: String { sid }
    let sid: String
    let n: Int
    let sendAt: Date
    var status: String
}

struct RunState: Codable {
    var config: Config          // snapshot taken at Start
    var startedAt: Date
    var endAt: Date?            // nil = until stopped
    var nextN: Int
    var lastSlot: Date?         // latest send time handed to Twilio
    var items: [ScheduledMessage]
}

enum Slots {
    /// Twilio needs SendAt ≥ 15 min after the request; keep a minute of slack.
    static let minLead: TimeInterval = 16 * 60
    /// Twilio max is 35 days; stay a bit inside it.
    static let maxLead: TimeInterval = 35 * 86_400 - 15 * 60
    /// "Until I stop it" keeps this much queued on Twilio's side.
    static let foreverHorizon: TimeInterval = 7 * 86_400

    /// Next send time after `prev`, never earlier than `earliest`.
    /// With `align`, snaps up to a multiple of the interval in local time (:00, :15, :30, :45).
    static func next(after prev: Date?, earliest: Date, intervalMin: Int, align: Bool,
                     timeZone: TimeZone = .current) -> Date {
        let step = TimeInterval(max(intervalMin, 1) * 60)
        var candidate = prev.map { $0.addingTimeInterval(step) } ?? earliest
        if candidate < earliest { candidate = earliest }
        guard align else { return candidate }
        let offset = TimeInterval(timeZone.secondsFromGMT(for: candidate))
        let local = candidate.timeIntervalSince1970 + offset
        let snapped = (local / step).rounded(.up) * step
        return Date(timeIntervalSince1970: snapped - offset)
    }

    static func render(_ template: String, n: Int, at date: Date) -> String {
        let f = DateFormatter()
        f.dateStyle = .medium
        f.timeStyle = .short
        return template
            .replacingOccurrences(of: "{n}", with: String(n))
            .replacingOccurrences(of: "{time}", with: f.string(from: date))
    }
}
