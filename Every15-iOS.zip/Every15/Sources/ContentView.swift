import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var store: AppStore

    var body: some View {
        NavigationStack {
            Form {
                statusSection

                Section("Message") {
                    TextField("To, e.g. +919876543210", text: $store.config.to)
                        .keyboardType(.phonePad)
                        .textContentType(.telephoneNumber)
                    TextField("Message", text: $store.config.message, axis: .vertical)
                        .lineLimit(2...6)
                    Picker("Channel", selection: $store.config.channel) {
                        ForEach(Channel.allCases) { Text($0.label).tag($0) }
                    }
                }
                .disabled(store.isRunning)

                Section {
                    Stepper("Every \(store.config.intervalMin) min",
                            value: $store.config.intervalMin, in: 5...240, step: 5)
                    Toggle("Align to clock (:00, :15, :30…)", isOn: $store.config.align)
                    Toggle("Send the first one now", isOn: $store.config.sendFirstNow)
                    Picker("Run for", selection: $store.config.runLength) {
                        ForEach(RunLength.allCases) { Text($0.label).tag($0) }
                    }
                } header: {
                    Text("Schedule")
                } footer: {
                    Text("{n} = message number, {time} = send time. Twilio needs 15 minutes' notice, so the first queued message goes out at least 16 minutes after you tap Start.")
                }
                .disabled(store.isRunning)

                Section {
                    TextField("Account SID (AC…)", text: $store.config.accountSid)
                    TextField("API Key SID (SK…, optional)", text: $store.config.apiKeySid)
                    SecureField(store.config.apiKeySid.isEmpty ? "Auth Token" : "API Key secret",
                                text: $store.secret)
                    TextField("Messaging Service SID (MG…)", text: $store.config.serviceSid)
                } header: {
                    Text("Twilio")
                } footer: {
                    Text("Messages are queued on Twilio, so they keep sending when your phone is off. The secret is stored in the Keychain.")
                }
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .disabled(store.isRunning)

                if let run = store.run, !run.items.isEmpty {
                    logSection(run)
                }
            }
            .navigationTitle("Every 15")
        }
    }

    @ViewBuilder
    private var statusSection: some View {
        Section {
            if let run = store.run {
                LabeledContent("Status", value: "Running")
                if let next = store.nextSend {
                    LabeledContent("Next", value: next.formatted(date: .omitted, time: .shortened))
                }
                if let through = run.lastSlot {
                    LabeledContent("Queued until", value: through.formatted(date: .abbreviated, time: .shortened))
                }
                LabeledContent("Waiting at Twilio", value: "\(store.pending.count)")
                if run.endAt == nil, let t = run.lastSlot, t < Date().addingTimeInterval(86_400) {
                    Label("Open the app soon to queue more", systemImage: "exclamationmark.triangle")
                        .foregroundStyle(.orange)
                }
                Button("Queue more now") { Task { await store.topUp(limit: 400) } }
                Button("Stop and cancel queued", role: .destructive) { Task { await store.stop() } }
            } else {
                Button("Start") { Task { await store.start() } }
                    .bold()
                Button("Send one test message") { Task { await store.sendTest() } }
            }
            if let b = store.busy {
                HStack(spacing: 10) { ProgressView(); Text(b).font(.footnote) }
            }
            if let e = store.error {
                Text(e).font(.footnote).foregroundStyle(.red)
            }
            if let i = store.info {
                Text(i).font(.footnote).foregroundStyle(.secondary)
            }
        }
        .disabled(store.busy != nil)
    }

    private func logSection(_ run: RunState) -> some View {
        let now = Date()
        let recent = run.items.filter { $0.sendAt <= now }.suffix(5)
        let upcoming = run.items.filter { $0.sendAt > now }.prefix(10)
        return Section("Messages") {
            ForEach(Array(recent) + Array(upcoming)) { m in
                HStack {
                    Text("#\(m.n)").monospacedDigit().foregroundStyle(.secondary)
                    Text(m.sendAt.formatted(date: .abbreviated, time: .shortened))
                    Spacer()
                    Text(m.sendAt <= now && m.status == "scheduled" ? "sent" : m.status)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
        }
    }
}
