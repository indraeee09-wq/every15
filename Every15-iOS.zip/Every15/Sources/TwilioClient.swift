import Foundation

struct TwilioMessage: Decodable, Sendable {
    let sid: String
    let status: String
}

struct TwilioError: LocalizedError, Sendable {
    let http: Int          // 0 = network / no response
    let code: Int?
    let message: String

    var retryable: Bool { http == 0 || http == 429 || http >= 500 }
    var errorDescription: String? {
        let prefix = http == 0 ? "Network" : "Twilio \(http)"
        return "\(prefix)\(code.map { " (#\($0))" } ?? ""): \(message)"
    }
}

/// Minimal Twilio REST client: send now, schedule for later, cancel a scheduled message.
/// Scheduling requires a Messaging Service SID (MG…) and a SendAt 15 min – 35 days ahead.
struct TwilioClient: Sendable {
    let accountSid: String
    let username: String   // Account SID, or API Key SID (SK…)
    let secret: String     // Auth Token, or API Key secret

    func send(to: String, serviceSid: String, body: String) async throws -> TwilioMessage {
        try await post("Messages.json", [
            ("To", to), ("MessagingServiceSid", serviceSid), ("Body", body),
        ])
    }

    func schedule(to: String, serviceSid: String, body: String, at date: Date) async throws -> TwilioMessage {
        try await post("Messages.json", [
            ("To", to), ("MessagingServiceSid", serviceSid), ("Body", body),
            ("ScheduleType", "fixed"), ("SendAt", Self.iso(date)),
        ])
    }

    func cancel(sid: String) async throws -> TwilioMessage {
        try await post("Messages/\(sid).json", [("Status", "canceled")])
    }

    // MARK: - Plumbing

    static func iso(_ date: Date) -> String {
        let f = ISO8601DateFormatter()
        f.formatOptions = [.withInternetDateTime]
        f.timeZone = TimeZone(identifier: "UTC")
        return f.string(from: date)
    }

    private static let unreserved = CharacterSet(
        charactersIn: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~")

    static func formEncode(_ pairs: [(String, String)]) -> Data {
        let s = pairs.map { key, value in
            let k = key.addingPercentEncoding(withAllowedCharacters: unreserved) ?? ""
            let v = value.addingPercentEncoding(withAllowedCharacters: unreserved) ?? ""
            return "\(k)=\(v)"
        }.joined(separator: "&")
        return Data(s.utf8)
    }

    private func post(_ path: String, _ form: [(String, String)]) async throws -> TwilioMessage {
        guard let url = URL(string: "https://api.twilio.com/2010-04-01/Accounts/\(accountSid)/\(path)") else {
            throw TwilioError(http: 0, code: nil, message: "Invalid Account SID")
        }
        var req = URLRequest(url: url, timeoutInterval: 20)
        req.httpMethod = "POST"
        req.setValue("Basic " + Data("\(username):\(secret)".utf8).base64EncodedString(),
                     forHTTPHeaderField: "Authorization")
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.httpBody = Self.formEncode(form)

        var last = TwilioError(http: 0, code: nil, message: "No response")
        for attempt in 1...3 {
            if attempt > 1 {
                try await Task.sleep(nanoseconds: UInt64(attempt * attempt) * 1_000_000_000)
            }
            let result: (Data, URLResponse)
            do {
                result = try await URLSession.shared.data(for: req)
            } catch {
                last = TwilioError(http: 0, code: nil, message: error.localizedDescription)
                continue
            }
            let (data, resp) = result
            let http = (resp as? HTTPURLResponse)?.statusCode ?? 0
            if (200..<300).contains(http) {
                if let m = try? JSONDecoder().decode(TwilioMessage.self, from: data) { return m }
                throw TwilioError(http: http, code: nil, message: "Unexpected response")
            }
            let obj = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
            last = TwilioError(
                http: http,
                code: obj?["code"] as? Int,
                message: obj?["message"] as? String ?? HTTPURLResponse.localizedString(forStatusCode: http))
            if !last.retryable { throw last }   // bad number, bad creds etc. won't fix themselves
        }
        throw last
    }
}
