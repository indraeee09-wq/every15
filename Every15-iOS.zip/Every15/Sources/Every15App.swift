import SwiftUI
import BackgroundTasks

@main
struct Every15App: App {
    @Environment(\.scenePhase) private var phase
    @StateObject private var store = AppStore.shared

    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(store)
        }
        .onChange(of: phase) { _, newPhase in
            switch newPhase {
            case .active:
                Task { await store.topUp(limit: 400) }
            case .background:
                BackgroundRefresh.schedule(running: store.isRunning)
            default:
                break
            }
        }
        .backgroundTask(.appRefresh(BackgroundRefresh.id)) {
            await BackgroundRefresh.run()
        }
    }
}

/// Opportunistic top-up while the app is closed. Twilio already holds days of
/// messages, so it doesn't matter when iOS decides to run this.
enum BackgroundRefresh {
    static let id = "com.example.every15.topup"   // must match BGTaskSchedulerPermittedIdentifiers

    static func schedule(running: Bool) {
        guard running else {
            BGTaskScheduler.shared.cancel(taskRequestWithIdentifier: id)
            return
        }
        let req = BGAppRefreshTaskRequest(identifier: id)
        req.earliestBeginDate = Date(timeIntervalSinceNow: 4 * 3600)
        try? BGTaskScheduler.shared.submit(req)
    }

    @MainActor
    static func run() async {
        let store = AppStore.shared
        await store.topUp(limit: 100)
        schedule(running: store.isRunning)
    }
}
