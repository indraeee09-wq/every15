#!/usr/bin/env bash
# Builds an UNSIGNED Every15.ipa (no Apple account needed). SideStore / Sideloadly / iloader
# sign it with your free Apple ID when you install it.
set -euo pipefail

fail() { echo "::error::$*"; exit 1; }
cd "$(dirname "$0")/.."

xcodebuild -version
command -v xcodegen >/dev/null || brew install xcodegen
xcodegen generate

WORK="${RUNNER_TEMP:-$(mktemp -d)}"
ARCHIVE="$WORK/Every15.xcarchive"
xcodebuild -quiet \
  -project Every15.xcodeproj -scheme Every15 -configuration Release \
  -destination 'generic/platform=iOS' -archivePath "$ARCHIVE" \
  archive \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO CODE_SIGN_IDENTITY="" \
  CURRENT_PROJECT_VERSION="${BUILD_NUMBER:-1}"

APP="$ARCHIVE/Products/Applications/Every15.app"
[ -d "$APP" ] || { ls -R "$ARCHIVE/Products" || true; fail "Archive did not contain Every15.app"; }

OUT="${OUT_DIR:-$PWD/..}"
rm -rf "$WORK/Payload" && mkdir -p "$WORK/Payload"
cp -R "$APP" "$WORK/Payload/"
( cd "$WORK" && zip -qry "$OUT/Every15.ipa" Payload )
echo "Built $OUT/Every15.ipa"
