#!/usr/bin/env bash
# Builds Every15 and uploads it to TestFlight. Runs on a GitHub macOS runner (no Mac needed).
#
# Signing: the archive is built unsigned, then `xcodebuild -exportArchive` signs it with
# Apple's cloud-managed distribution certificate using an App Store Connect Team API key
# (Admin role). No .p12, no provisioning profile, no registered devices.
#
# Env (GitHub secrets): ASC_KEY_ID, ASC_ISSUER_ID, ASC_PRIVATE_KEY, APPLE_TEAM_ID, BUNDLE_ID
# Optional: BUILD_NUMBER (defaults to a timestamp)
set -euo pipefail

fail() { echo "::error::$*"; exit 1; }

for v in ASC_KEY_ID ASC_ISSUER_ID ASC_PRIVATE_KEY APPLE_TEAM_ID BUNDLE_ID; do
  [ -n "${!v:-}" ] || fail "Secret $v is missing. Add it under Settings → Secrets and variables → Actions."
done
[[ "$APPLE_TEAM_ID" =~ ^[A-Z0-9]{10}$ ]] || fail "APPLE_TEAM_ID should be 10 letters/digits, e.g. AB12CD34EF."
[[ "$BUNDLE_ID" =~ ^[A-Za-z0-9.-]+$ ]] || fail "BUNDLE_ID should look like com.yourname.every15."
BUILD_NUMBER="${BUILD_NUMBER:-$(date -u +%Y%m%d%H%M)}"

cd "$(dirname "$0")/.."

xcodebuild -version
xcode_major=$(xcodebuild -version | awk 'NR==1 { split($2, a, "."); print a[1] }')
[ "$xcode_major" -ge 26 ] || fail "App Store Connect needs Xcode 26 or later; this runner has Xcode $xcode_major."

command -v xcodegen >/dev/null || brew install xcodegen
xcodegen generate

WORK="${RUNNER_TEMP:-$(mktemp -d)}"
KEY="$WORK/AuthKey_${ASC_KEY_ID}.p8"
( umask 077
  # Strip Windows line endings and leading blank lines that creep in when pasting.
  printf '%s\n' "$ASC_PRIVATE_KEY" | tr -d '\r' | sed '/./,$!d' > "$KEY" )
trap 'rm -f "$KEY"' EXIT
grep -q -- "-----BEGIN PRIVATE KEY-----" "$KEY" \
  || fail "ASC_PRIVATE_KEY must be the whole .p8 file, including the BEGIN/END PRIVATE KEY lines."

ARCHIVE="$WORK/Every15.xcarchive"
echo "::group::Archive (build $BUILD_NUMBER)"
xcodebuild -quiet \
  -project Every15.xcodeproj -scheme Every15 -configuration Release \
  -destination 'generic/platform=iOS' -archivePath "$ARCHIVE" \
  archive \
  CODE_SIGNING_ALLOWED=NO \
  DEVELOPMENT_TEAM="$APPLE_TEAM_ID" \
  PRODUCT_BUNDLE_IDENTIFIER="$BUNDLE_ID" \
  CURRENT_PROJECT_VERSION="$BUILD_NUMBER"
echo "::endgroup::"

APP="$ARCHIVE/Products/Applications/Every15.app"
[ -d "$APP" ] || { ls -R "$ARCHIVE/Products" || true; fail "Archive did not contain Every15.app"; }
# Placeholder signature so export has something to re-sign.
codesign --force --sign - "$APP"

OPTS="$WORK/ExportOptions.plist"
cp ci/ExportOptions.plist "$OPTS"
plutil -replace teamID -string "$APPLE_TEAM_ID" "$OPTS"

echo "::group::Sign and upload to App Store Connect"
xcodebuild -exportArchive \
  -archivePath "$ARCHIVE" \
  -exportOptionsPlist "$OPTS" \
  -exportPath "$WORK/export" \
  -allowProvisioningUpdates \
  -authenticationKeyPath "$KEY" \
  -authenticationKeyID "$ASC_KEY_ID" \
  -authenticationKeyIssuerID "$ASC_ISSUER_ID"
echo "::endgroup::"

echo "Uploaded build $BUILD_NUMBER of $BUNDLE_ID. It appears in TestFlight after Apple finishes processing (about 5–30 min)."
{
  echo "### Uploaded to TestFlight"
  echo "Build **$BUILD_NUMBER** of \`$BUNDLE_ID\`. Open the TestFlight app on your iPhone in 5–30 minutes."
} >> "${GITHUB_STEP_SUMMARY:-/dev/null}"
