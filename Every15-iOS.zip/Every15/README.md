# Every 15 — iPhone app (iOS 17+, runs on iPhone 17)

Sends a message to one number every 15 minutes (or any interval) through Twilio, by SMS or WhatsApp.

iOS doesn't let apps send texts by themselves or run every 15 minutes in the background. So when you tap **Start**, the app hands Twilio a queue of timed messages, and Twilio sends them even if your phone is off.

- **Fixed run** (1 hour to 35 days): everything is queued up front.
- **Until I stop it**: about 7 days stay queued. The app adds more each time you open it.
- **Stop** cancels everything still queued at Twilio.

## Install without a Mac (GitHub builds it, TestFlight installs it)

You need a paid Apple Developer Program membership. The full step-by-step is in the chat where you got this file. In short:

1. Register a bundle ID, create the app in App Store Connect, and create a **Team** API key with **Admin** access.
2. In a GitHub repo, upload `Every15-iOS.zip` and add `ci/github-workflow.yml` as `.github/workflows/ios.yml`.
3. Add 5 repo secrets: `ASC_KEY_ID`, `ASC_ISSUER_ID`, `ASC_PRIVATE_KEY` (the whole .p8 text), `APPLE_TEAM_ID`, `BUNDLE_ID`.
4. Go to Actions → **iPhone TestFlight** → **Run workflow**.
5. When it finishes, install the app from the TestFlight app on your iPhone.

TestFlight builds expire after 90 days. To renew, run the workflow again.

## With a Mac (optional)

```
brew install xcodegen
xcodegen
open Every15.xcodeproj
```

Pick your Team, set a unique bundle ID, and run it on your phone.

## Twilio setup

1. Create a **Messaging Service** and add your number as a sender. Copy its MG… SID.
2. Use your Account SID with either your Auth Token or an API Key (SK… plus its secret).
3. SMS to +91 numbers needs DLT registration. WhatsApp needs an approved template.

`{n}` in the message becomes the message number and `{time}` becomes the send time.
